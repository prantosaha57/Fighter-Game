package javagame;

/** 
 * 
 * @author Pranto 
 */ 
public class Player2 extends Player1 { 
 
    private int health; 
    private boolean armour; 
 
    public Player2(String name, String weapon, int health, boolean armour) { 
        super(name, weapon, health); 
        this.health = health; 
        this.armour = armour; 
    } 
 
    @Override 
    public void damageByGun1() { 
        if (armour) { 
            this.health -= 20; 
            if (this.health <= 0) { 
                this.health = 0; 
            } 
            System.out.println("Tonni's Armour is off. \nTonni Got hit by Gun. \nHealth is reduced by 20." 
                    + "\nNew health is " + this.health); 
 
        } 
        if (!armour) { 
            this.health -= 30; 
            if (this.health <= 0) { 
                this.health = 0; 
            } 
            System.out.println("Tonni's Armour is on. \nTonni Got hit by gun " + getWeapon() + "\nHealth is reduced by 20." 
                    + "\nNew health is " + this.health); 
 
        } 
        if (this.health == 0) { 
            System.out.println(getName() + " is dead"); 
            System.out.println("\n\nYou Win the game!!!\n\n"); 
            System.exit(0); 
        } 
    } 
 
    @Override 
    public void damageByGun2() { 
        if (armour) { 
            this.health -= 40; 
            if (this.health <= 0) { 
                this.health = 0; 
            } 
            System.out.println(getName() + "'s Armour is on. Got hit by gun 1.\nHealth is reduced by 40." 
                    + "\nNew health is " + this.health); 
        } 
        if (!armour) { 
            this.health -= 50; 
            if (this.health <= 0) { 
                this.health = 0; 
            } 
            System.out.println(getName() + "'s Armour is off.\nGot hit by gun 1.\nHealth is reduced by 50." 
                    + "\nNew health is " + this.health); 
        } 
        if (this.health == 0) { 
            System.out.println(getName() + " is dead"); 
            System.out.println("\n\nYou Win the game!!!\n\n"); 
 
            System.exit(0); 
        } 
    } 
 
    public void heal() { 
        if (this.health <= 0) { 
            System.out.println("Player is dead. Heal not possible"); 
            System.out.println("\n\nYou Win the game!!!\n\n"); 
            System.exit(0); 
        } else { 
            this.health = 100; 
            System.out.println("Health is " + this.health); 
        } 
    } 
}
