package javagame;

import java.util.Scanner;

/**
 *
 * @author Pranto
 */
public class Main {
    public static void main(String[] args) { 
        Scanner input = new Scanner(System.in); 
 
        System.out.println("Enter the Game :"); 
        System.out.print("Enter Name     :"); 
        String name = input.nextLine(); 
        System.out.print("Enter Gun      :"); 
        String gun = input.nextLine(); 
        System.out.println("Your Health  : 100\n\n"); 
         
        Player1 player = new Player1(name, gun, 100); 
        Player2 betterPlayer = new Player2("Tonni", "Knife", 100, true); 
 
        while (1 == 1) { 
            System.out.println("\n\n1) Shoot by Gun 1  to "+name); 
            System.out.println("2) Shoot by Gun 2  to "+name); 
            System.out.println("3) Shoot by Gun 1 to Tonni"); 
            System.out.println("4) Shoot by Gun 2 to Tonni"); 
            System.out.println("5) Healing Player "+name); 
            System.out.println("6) Healing Tonni           "); 
            System.out.println("7) Exit            \n\n"); 
 
            int s = input.nextInt(); 
 
            if (s == 1) { 
                player.damageByGun1(); 
 
            } else if (s == 2) { 
                player.damageByGun2(); 
 
            } else if (s == 5) { 
                player.heal(); 
 
            } else if (s == 3) { 
                betterPlayer.damageByGun1(); 
 
            } else if (s == 4) { 
                betterPlayer.damageByGun2(); 
 
            } else if (s == 6) { 
                betterPlayer.heal(); 
            } else if (s == 7) { 
                 System.out.println("Exit From the GAME!!!"); 
                System.exit(0);
 
            } else { 
                System.out.println("Invalid input ...try again"); 
 
            } 
 
        } 
 
    } 
}
