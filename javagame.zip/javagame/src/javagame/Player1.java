package javagame;

/**
 *
 * @author Pranto
 */
public class Player1 {

    private String name;
    private String weapon;
    public int health;

    public Player1(String name, String weapon, int health) {
        this.name = name;
        this.weapon = weapon;
        if (health < 0 || health > 100) {
            this.health = 100;
        } else {
            this.health = health;
        }
    }

    public void damageByGun1() {
        this.health -= 30;
        if (this.health <= 0) {
            this.health = 0;
        }
        System.out.println(getName() + " Got hit by gun " + getWeapon() + " \nHealth is reduced by 30"
                + ". \nNew health is " + this.health);
        if (this.health == 0) {
            System.out.println(getName() + " is dead");
            System.out.println("\n\nTonni Wins the game!!!\n\n");
            System.exit(0);
        }
    }

    public void damageByGun2() {
        this.health -= 50;
        if (this.health <= 0) {
            this.health = 0;
        }
        System.out.println(getName() + " Got hit by gun Knife. \nHealth is reduced by 50" + ". \nNew health is " + this.health);
        if (this.health == 0) {
            System.out.println(getName() + " is dead");
            System.out.println("\n\nTonni Wins the game!!!\n\n");
            System.exit(0);
        }
    }

    public void heal() {
        if (this.health <= 0) {
            System.out.println("Player is dead. Heal not possible");
            System.out.println("\n\nTonni Wins the game!!!\n\n");
            System.exit(0);
        } else {
            this.health = 100;
            System.out.println("Got Healed ! New Health is " + this.health);
        }
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getWeapon() {
        return weapon;
    }

    public void setWeapon(String weapon) {
        this.weapon = weapon;
    }

}
